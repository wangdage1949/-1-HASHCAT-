#define _CRT_SECURE_NO_WARNINGS
#define NOMINMAX
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <string>
#include <algorithm>
#include <sstream>
#include <ctime>
#include <cstdint>
#include <cmath>
#include <map>
#include <cstring>
#include <random>

using namespace std;

// ============================================================================
// CONSOLE COLOR CODES
// ============================================================================

#define COLOR_RESET   ""
#define COLOR_RED     ""
#define COLOR_GREEN   ""
#define COLOR_YELLOW  ""
#define COLOR_BLUE    ""
#define COLOR_MAGENTA ""
#define COLOR_CYAN    ""
#define COLOR_WHITE   ""

// ============================================================================
// PROGRESS AND DISPLAY FUNCTIONS
// ============================================================================

void clearLine() {
    cout << "\r" << string(80, ' ') << "\r";
}

void showProgress(size_t current, size_t total, const string& message = "", bool forceShow = false) {
    static size_t last_shown = 0;
    
    if (forceShow || (total > 0 && (current * 100 / total != last_shown * 100 / total))) {
        float percentage = (static_cast<float>(current) / total) * 100.0f;
        stringstream ss;
        ss << "\rProgress: [" << fixed << setprecision(1) << percentage << "%] ";
        ss << "Processed " << current << "/" << total << " bytes";
        if (!message.empty()) {
            ss << " - " << message;
        }
        cout << ss.str() << flush;
        last_shown = current;
    }
}

void printInfo(const string& message) {
    cout << "[INFO] " << message << endl;
}

void printSuccess(const string& message) {
    cout << "[SUCCESS] " << message << endl;
}

void printWarning(const string& message) {
    cout << "[WARNING] " << message << endl;
}

void printError(const string& message) {
    cout << "[ERROR] " << message << endl;
}

// ============================================================================
// FILE READING UTILITIES
// ============================================================================

vector<uint8_t> readEntireFile(const string& filename, bool showProgressFlag = true) {
    ifstream file(filename, ios::binary | ios::ate);
    if (!file) {
        printError("Cannot open file: " + filename);
        return {};
    }
    
    streamsize size = file.tellg();
    file.seekg(0, ios::beg);
    
    printInfo("Reading " + to_string(size) + " bytes from " + filename);
    
    vector<uint8_t> buffer(size);
    
    const size_t chunkSize = 64 * 1024; // 64KB chunks
    streamsize totalRead = 0;
    
    while (totalRead < size) {
        streamsize toRead = min<streamsize>(chunkSize, size - totalRead);
        file.read(reinterpret_cast<char*>(buffer.data() + totalRead), toRead);
        totalRead += toRead;
        
        if (showProgressFlag) {
            showProgress(static_cast<size_t>(totalRead), static_cast<size_t>(size), "Reading");
        }
    }
    
    file.close();
    
    if (showProgressFlag) {
        clearLine();
        printSuccess("File reading completed");
    }
    
    return buffer;
}

// ============================================================================
// HEX DUMP UTILITIES
// ============================================================================

void hexDump(const uint8_t* data, size_t size, size_t offset = 0, size_t bytesPerLine = 16) {
    for (size_t i = 0; i < size; i += bytesPerLine) {
        // Print offset
        cout << hex << setw(8) << setfill('0') << offset + i << ": ";
        
        // Print hex bytes
        for (size_t j = 0; j < bytesPerLine; j++) {
            if (i + j < size) {
                cout << hex << setw(2) << setfill('0') << static_cast<int>(data[i + j]) << " ";
            } else {
                cout << "   ";
            }
            
            if (j == 7) cout << " ";
        }
        
        cout << " ";
        
        // Print ASCII representation
        for (size_t j = 0; j < bytesPerLine; j++) {
            if (i + j < size) {
                uint8_t c = data[i + j];
                if (c >= 32 && c <= 126) {
                    cout << c;
                } else {
                    cout << ".";
                }
            } else {
                cout << " ";
            }
        }
        
        cout << endl;
    }
    cout << dec;
}

// ============================================================================
// WALLET STRUCTURE ANALYSIS
// ============================================================================

struct WalletKeyEntry {
    string type;                    // "mkey", "ckey", "key", etc.
    size_t offset;                  // Position in file
    uint8_t version;                // Encryption version (0x00-0x03)
    vector<uint8_t> nonce;          // 16 bytes AES nonce
    vector<uint8_t> encryptedData;  // Encrypted data
    size_t dataLength;              // Length of encrypted data
    vector<uint8_t> fullEntry;      // Complete entry for reference
};

// Helper function to search for byte patterns
vector<size_t> findAllOccurrences(const vector<uint8_t>& data, const string& pattern) {
    vector<size_t> positions;
    vector<uint8_t> patternBytes(pattern.begin(), pattern.end());
    
    for (size_t i = 0; i + patternBytes.size() <= data.size(); i++) {
        bool found = true;
        for (size_t j = 0; j < patternBytes.size(); j++) {
            if (data[i + j] != patternBytes[j]) {
                found = false;
                break;
            }
        }
        if (found) {
            positions.push_back(i);
        }
    }
    
    return positions;
}

vector<WalletKeyEntry> analyzeWalletStructure(const vector<uint8_t>& data) {
    vector<WalletKeyEntry> entries;
    
    printInfo("Analyzing wallet structure...");
    
    // Known Bitcoin Core key types
    vector<string> keyTypes = {"mkey", "ckey", "key", "wkey", "pool", "name", "version", "defaultkey"};
    
    for (const auto& keyType : keyTypes) {
        // Find all occurrences of this key type
        vector<size_t> positions = findAllOccurrences(data, keyType);
        
        for (size_t pos : positions) {
            showProgress(pos, data.size(), "Searching for " + keyType);
            
            WalletKeyEntry entry;
            entry.type = keyType;
            entry.offset = pos;
            
            // Try to parse the structure
            size_t typeLen = keyType.length();
            size_t lengthPos = pos + typeLen;
            
            if (lengthPos + 4 <= data.size()) {
                // Read length (4 bytes, little endian)
                entry.dataLength = static_cast<size_t>(data[lengthPos]) |
                                 (static_cast<size_t>(data[lengthPos + 1]) << 8) |
                                 (static_cast<size_t>(data[lengthPos + 2]) << 16) |
                                 (static_cast<size_t>(data[lengthPos + 3]) << 24);
                
                size_t versionPos = lengthPos + 4;
                
                if (versionPos < data.size()) {
                    entry.version = data[versionPos];
                    
                    // Version should be 0x00, 0x01, 0x02, or 0x03
                    if (entry.version <= 0x03) {
                        size_t noncePos = versionPos + 1;
                        
                        if (noncePos + 16 <= data.size()) {
                            // Extract nonce
                            entry.nonce.resize(16);
                            copy(data.begin() + noncePos, data.begin() + noncePos + 16, entry.nonce.begin());
                            
                            // Extract encrypted data
                            size_t dataStart = noncePos + 16;
                            size_t dataEnd = min(dataStart + entry.dataLength, data.size());
                            
                            if (dataEnd <= data.size()) {
                                entry.encryptedData.resize(dataEnd - dataStart);
                                copy(data.begin() + dataStart, data.begin() + dataEnd, entry.encryptedData.begin());
                                
                                // Store complete entry for reference
                                size_t entryEnd = min(pos + typeLen + 4 + 1 + 16 + entry.dataLength, data.size());
                                entry.fullEntry.resize(entryEnd - pos);
                                copy(data.begin() + pos, data.begin() + entryEnd, entry.fullEntry.begin());
                                
                                entries.push_back(entry);
                                
                                stringstream ss;
                                ss << "Found " << keyType << " at offset 0x" << hex << pos << dec
                                   << " (nonce at 0x" << hex << noncePos << dec << ")";
                                printInfo(ss.str());
                            }
                        }
                    }
                }
            }
        }
        
        if (!positions.empty()) {
            printInfo("Found " + to_string(positions.size()) + " " + keyType + " entries");
        }
    }
    
    clearLine();
    return entries;
}

// ============================================================================
// ADVANCED NONCE DETECTION
// ============================================================================

vector<vector<uint8_t>> findPotentialNonces(const vector<uint8_t>& data) {
    vector<vector<uint8_t>> nonces;
    
    printInfo("Performing advanced nonce detection...");
    
    // Look for 16-byte sequences that look like random nonces
    // Nonces typically have high entropy
    for (size_t i = 0; i + 16 <= data.size(); i++) {
        if (i % 65536 == 0) {
            showProgress(i, data.size(), "Searching for nonce patterns");
        }
        
        // Check if the 16-byte sequence could be a nonce
        vector<uint8_t> candidate(16);
        copy(data.begin() + i, data.begin() + i + 16, candidate.begin());
        
        // Calculate simple entropy (count of unique bytes)
        map<uint8_t, int> byteCount;
        for (uint8_t b : candidate) {
            byteCount[b]++;
        }
        
        // Good nonces have many unique bytes
        if (byteCount.size() >= 10) {
            // Check if preceded by version byte
            if (i > 0 && data[i - 1] <= 0x03) {
                nonces.push_back(candidate);
            }
            // Or if at a 16-byte boundary (common in encrypted data)
            else if (i % 16 == 0) {
                nonces.push_back(candidate);
            }
        }
    }
    
    clearLine();
    return nonces;
}

// ============================================================================
// NONCE ANALYSIS AND REPORTING
// ============================================================================

void analyzeAndReportNonces(const vector<WalletKeyEntry>& entries, const vector<uint8_t>& data) {
    printInfo("Generating nonce analysis report...");
    
    ofstream report("nonce_analysis_report.txt");
    ofstream raw_nonces("extracted_nonces.raw", ios::binary);
    
    if (!report) {
        printError("Cannot create report file");
        return;
    }
    
    time_t now = time(nullptr);
    char timeStr[26];
    ctime_s(timeStr, sizeof(timeStr), &now);
    
    report << "=== Bitcoin Wallet Nonce Analysis Report ===\n";
    report << "Generated: " << timeStr;
    report << "File size: " << data.size() << " bytes\n";
    report << "Total key entries found: " << entries.size() << "\n\n";
    
    // Group entries by type
    map<string, vector<WalletKeyEntry>> groupedEntries;
    for (const auto& entry : entries) {
        groupedEntries[entry.type].push_back(entry);
    }
    
    // Report by type
    for (const auto& group : groupedEntries) {
        report << "=== " << group.first << " ENTRIES (" << group.second.size() << " found) ===\n\n";
        
        for (size_t i = 0; i < group.second.size(); i++) {
            const auto& entry = group.second[i];
            
            report << "Entry #" << (i + 1) << ":\n";
            report << "  Offset: 0x" << hex << entry.offset << dec << " (" << entry.offset << ")\n";
            report << "  Version: 0x" << hex << setw(2) << setfill('0') 
                   << static_cast<int>(entry.version) << dec << "\n";
            report << "  Data length: " << entry.dataLength << " bytes\n";
            
            report << "  Nonce (16 bytes): ";
            for (size_t j = 0; j < entry.nonce.size(); j++) {
                report << hex << setw(2) << setfill('0') 
                       << static_cast<int>(entry.nonce[j]) << " ";
            }
            report << dec << "\n";
            
            report << "  Nonce as string: ";
            for (uint8_t b : entry.nonce) {
                if (b >= 32 && b <= 126) {
                    report << static_cast<char>(b);
                } else {
                    report << ".";
                }
            }
            report << "\n\n";
            
            // Write nonce to raw file
            if (raw_nonces) {
                raw_nonces.write(reinterpret_cast<const char*>(entry.nonce.data()), entry.nonce.size());
            }
        }
    }
    
    // Also look for standalone nonces
    vector<vector<uint8_t>> potentialNonces = findPotentialNonces(data);
    if (!potentialNonces.empty()) {
        report << "=== STANDALONE POTENTIAL NONCES (" << potentialNonces.size() << " found) ===\n\n";
        
        for (size_t i = 0; i < potentialNonces.size(); i++) {
            report << "Nonce #" << (i + 1) << ":\n  ";
            for (uint8_t b : potentialNonces[i]) {
                report << hex << setw(2) << setfill('0') << static_cast<int>(b) << " ";
            }
            report << dec << "\n\n";
        }
    }
    
    // Add hex dump of first few key entries
    if (!entries.empty()) {
        report << "=== HEX DUMPS OF KEY ENTRIES ===\n\n";
        
        for (size_t i = 0; i < min(entries.size(), static_cast<size_t>(3)); i++) {
            const auto& entry = entries[i];
            report << "Entry #" << (i + 1) << " (" << entry.type << ") at offset 0x" 
                   << hex << entry.offset << dec << ":\n";
            
            // Simple hex dump
            size_t dumpSize = min(static_cast<size_t>(64), entry.fullEntry.size());
            for (size_t j = 0; j < dumpSize; j++) {
                if (j % 16 == 0) {
                    report << "\n  " << hex << setw(4) << setfill('0') << j << ": ";
                }
                report << hex << setw(2) << setfill('0') 
                       << static_cast<int>(entry.fullEntry[j]) << " ";
            }
            report << dec << "\n\n";
        }
    }
    
    report << "=== ANALYSIS COMPLETE ===\n";
    report.close();
    
    if (raw_nonces) {
        raw_nonces.close();
        printSuccess("Raw nonces saved to: extracted_nonces.raw");
    }
    
    printSuccess("Analysis report saved to: nonce_analysis_report.txt");
}

// ============================================================================
// MAIN FUNCTION
// ============================================================================

int main(int argc, char* argv[]) {
    cout << "=====================================================\n";
    cout << "   Bitcoin Wallet Forensic Analyzer v1.0          \n";
    cout << "   Advanced Nonce Extraction & Analysis           \n";
    cout << "=====================================================\n";
    
    if (argc < 2) {
        printError("Usage: " + string(argv[0]) + " <wallet.dat> [options]");
        cout << "\nOptions:\n";
        cout << "  --all        : Full analysis (default)\n";
        cout << "  --quick      : Quick scan only\n";
        cout << "  --verbose    : Show detailed information\n";
        cout << "  --hexdump    : Show hex dump of key areas\n";
        cout << "  --output <file> : Custom output filename\n";
        return 1;
    }
    
    string walletFile = argv[1];
    bool verbose = false;
    bool quickScan = false;
    bool showHexDump = false;
    string outputFile = "nonce_analysis_report.txt";
    
    // Parse arguments
    for (int i = 2; i < argc; i++) {
        string arg = argv[i];
        if (arg == "--all" || arg == "-a") {
            // Default behavior
        } else if (arg == "--quick" || arg == "-q") {
            quickScan = true;
        } else if (arg == "--verbose" || arg == "-v") {
            verbose = true;
        } else if (arg == "--hexdump" || arg == "-h") {
            showHexDump = true;
        } else if (arg == "--output" || arg == "-o") {
            if (i + 1 < argc) {
                outputFile = argv[++i];
            }
        }
    }
    
    printInfo("Analyzing file: " + walletFile);
    
    // Read the file
    vector<uint8_t> fileData = readEntireFile(walletFile, true);
    
    if (fileData.empty()) {
        printError("Failed to read file or file is empty");
        return 1;
    }
    
    // First, let's just search for "mkey" string to understand the structure
    printInfo("Searching for 'mkey' pattern...");
    
    vector<size_t> mkeyPositions = findAllOccurrences(fileData, "mkey");
    
    printInfo("Found " + to_string(mkeyPositions.size()) + " occurrences of 'mkey'");
    
    // Show hex dump of each mkey position if requested
    if (showHexDump && !mkeyPositions.empty()) {
        for (size_t i = 0; i < min(mkeyPositions.size(), static_cast<size_t>(3)); i++) {
            size_t pos = mkeyPositions[i];
            cout << "\nHex dump around 'mkey' at offset 0x" 
                 << hex << pos << dec << ":" << endl;
            
            size_t start = (pos > 32) ? pos - 32 : 0;
            size_t end = min(pos + 96, fileData.size());
            hexDump(fileData.data() + start, end - start, start);
        }
    }
    
    // Analyze wallet structure
    vector<WalletKeyEntry> walletEntries = analyzeWalletStructure(fileData);
    
    if (walletEntries.empty()) {
        printWarning("No standard wallet key entries found. Trying alternative detection...");
        
        // Try to find nonces by pattern
        vector<vector<uint8_t>> potentialNonces = findPotentialNonces(fileData);
        
        if (!potentialNonces.empty()) {
            printSuccess("Found " + to_string(potentialNonces.size()) + " potential nonces");
            
            // Create a simple report
            ofstream report("potential_nonces.txt");
            if (report) {
                report << "=== Potential Nonces Found ===\n\n";
                for (size_t i = 0; i < potentialNonces.size(); i++) {
                    report << "Nonce #" << (i + 1) << ":\n  ";
                    for (uint8_t b : potentialNonces[i]) {
                        report << hex << setw(2) << setfill('0') << static_cast<int>(b) << " ";
                    }
                    report << dec << "\n\n";
                }
                report.close();
                printSuccess("Potential nonces saved to: potential_nonces.txt");
            }
        } else {
            printWarning("No nonces found using any detection method");
            
            // Try one more approach: look for 16-byte sequences after version bytes
            printInfo("Trying final detection method...");
            vector<vector<uint8_t>> finalAttempt;
            
            for (size_t i = 0; i + 17 < fileData.size(); i++) {
                if (fileData[i] <= 0x03) { // Version byte
                    // Check if next 16 bytes look random
                    bool seen[256] = {false};
                    int uniqueCount = 0;
                    
                    for (int j = 0; j < 16; j++) {
                        uint8_t val = fileData[i + 1 + j];
                        if (!seen[val]) {
                            seen[val] = true;
                            uniqueCount++;
                        }
                    }
                    
                    if (uniqueCount > 10) {
                        vector<uint8_t> nonce(16);
                        copy(fileData.begin() + i + 1, fileData.begin() + i + 17, nonce.begin());
                        finalAttempt.push_back(nonce);
                        
                        if (verbose) {
                            cout << "Found nonce candidate at 0x" << hex << (i + 1) 
                                 << " (after version 0x" << static_cast<int>(fileData[i]) << ")" << dec << endl;
                        }
                    }
                }
            }
            
            if (!finalAttempt.empty()) {
                printSuccess("Found " + to_string(finalAttempt.size()) + " nonce candidates");
                
                ofstream finalReport("nonce_candidates.txt");
                if (finalReport) {
                    for (size_t i = 0; i < finalAttempt.size(); i++) {
                        finalReport << "Candidate #" << (i + 1) << ":\n  ";
                        for (uint8_t b : finalAttempt[i]) {
                            finalReport << hex << setw(2) << setfill('0') << static_cast<int>(b) << " ";
                        }
                        finalReport << dec << "\n\n";
                    }
                    finalReport.close();
                    printSuccess("Nonce candidates saved to: nonce_candidates.txt");
                }
            }
        }
    } else {
        printSuccess("Found " + to_string(walletEntries.size()) + " wallet key entries");
        
        // Generate detailed report
        analyzeAndReportNonces(walletEntries, fileData);
        
        // Show summary
        cout << "\n=== ANALYSIS SUMMARY ===" << endl;
        
        map<string, int> typeCount;
        for (const auto& entry : walletEntries) {
            typeCount[entry.type]++;
        }
        
        for (const auto& count : typeCount) {
            cout << "  " << count.first << ": " 
                 << count.second << " entries" << endl;
        }
        
        // Show example nonce
        if (!walletEntries.empty()) {
            cout << "\nExample nonce from first " << walletEntries[0].type 
                 << " entry:" << endl;
            cout << "  Hex: ";
            for (size_t i = 0; i < min(static_cast<size_t>(16), walletEntries[0].nonce.size()); i++) {
                cout << hex << setw(2) << setfill('0') 
                     << static_cast<int>(walletEntries[0].nonce[i]) << " ";
            }
            cout << dec << endl;
            
            // Save all nonces to binary file
            ofstream allNonces("all_extracted_nonces.bin", ios::binary);
            if (allNonces) {
                for (const auto& entry : walletEntries) {
                    allNonces.write(reinterpret_cast<const char*>(entry.nonce.data()), entry.nonce.size());
                }
                allNonces.close();
                printSuccess("All nonces saved to binary file: all_extracted_nonces.bin");
            }
        }
    }
    
    // Generate final summary
    cout << "\n=====================================================\n";
    cout << "   ANALYSIS COMPLETE\n";
    cout << "=====================================================\n";
    
    cout << "\nGenerated files:\n";
    
    // Check which files were created
    auto fileExists = [](const string& filename) {
        ifstream f(filename);
        return f.good();
    };
    
    if (fileExists("nonce_analysis_report.txt")) {
        cout << "  - nonce_analysis_report.txt (detailed analysis)\n";
    }
    if (fileExists("extracted_nonces.raw")) {
        cout << "  - extracted_nonces.raw (raw nonce data)\n";
    }
    if (fileExists("all_extracted_nonces.bin")) {
        cout << "  - all_extracted_nonces.bin (all nonces binary)\n";
    }
    if (fileExists("potential_nonces.txt")) {
        cout << "  - potential_nonces.txt (potential nonces)\n";
    }
    if (fileExists("nonce_candidates.txt")) {
        cout << "  - nonce_candidates.txt (nonce candidates)\n";
    }
    
    cout << "\nNext steps:\n";
    cout << "  1. Check the generated reports for extracted nonces\n";
    cout << "  2. Use nonces for wallet recovery or analysis\n";
    cout << "  3. Compare with known wallet structures\n";
    
    cout << "\nPress Enter to exit...";
    cin.get();
    
    return 0;
}