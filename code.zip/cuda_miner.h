#ifndef CUDA_MINER_H
#define CUDA_MINER_H

#include <vector>
#include <cstdint>

#ifdef __cplusplus
extern "C" {
#endif

bool cuda_available();
bool cuda_initialize(int device_id);
void cuda_cleanup();

bool cuda_generate_plaintexts(std::vector<std::vector<uint8_t>>& plaintexts, 
                               uint64_t seed, int batch_size);

bool cuda_calculate_similarities(const std::vector<std::vector<uint8_t>>& ciphertexts,
                                 const std::vector<uint8_t>& reference,
                                 std::vector<double>& similarities);

#ifdef __cplusplus
}
#endif

#endif