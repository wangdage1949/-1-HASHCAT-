#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <sstream>
#include <cstring>
#include <filesystem>
#include <random>
#include <algorithm>
#include <chrono>
#include <thread>
#include <atomic>
#include <mutex>
#include <memory>
#include <fstream>

// Berkeley DB
#include <db_cxx.h>

// OpenSSL
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <openssl/rand.h>
#include <openssl/err.h>
#include <openssl/aes.h>

// GPU support
#ifdef USE_CUDA
#include <cuda_runtime.h>  // ADĂUGAT: Include pentru funcțiile CUDA runtime
#include "gpu_miner.cuh"
#endif

using namespace std;

// --- Configurație ---
struct Config {
    // Mode settings
    bool enableBruteForce = false;
    double targetSimilarity = 0.5;
    uint64_t bruteForceMaxAttempts = 0;
    int progressUpdateInterval = 100;
    int fixedRounds = 1;
    bool useFixedSalt = true;
    bool showFullCiphertext = true;
    
    // CPU settings
    int numThreads = 4;
    
    // GPU settings
    bool useGPU = false;
    int gpuDeviceId = 0;
    uint64_t gpuBatchSize = 65536;  // Folosit pentru GPU complet
    
    // Performance settings
    bool ultraFastMode = false;
    bool fastMode = false;
    bool fullOutput = false;
    
    // Files and passwords
    string walletFile;
    string password = "123";
    
    // Nonce settings
    string nonceFile;           // Fișierul cu nonce-uri extrase
    bool useExtractedNonces = false; // Folosește nonce-uri extrase
    size_t selectedNonceIndex = 0;   // Indexul nonce-ului selectat
    bool testAllNonces = false;      // Testează toate nonce-urile
    
    // Added: Salt size handling
    bool preserveOriginalSaltSize = true; // Păstrează dimensiunea originală a salt-ului
};

// --- Structură pentru rezultate thread-safe ---
struct ThreadResult {
    vector<uint8_t> bestPlaintext;
    vector<uint8_t> bestCiphertext;
    uint32_t bestRounds;
    double bestSimilarity = 0.0;
    uint64_t bestAttempt = 0;
    atomic<bool> targetReached{false};
    mutable mutex mtx;  // MODIFICARE: mutex marcat ca mutable
    
    // Constructor de copiere explicit
    ThreadResult() = default;
    
    // Constructor de copiere - DELETED pentru a preveni copierea accidentala
    ThreadResult(const ThreadResult&) = delete;
    
    // Operator de atribuire - DELETED
    ThreadResult& operator=(const ThreadResult&) = delete;
    
    // Funcție pentru copierea manuală a datelor
    void copyFrom(const ThreadResult& other) {
        lock_guard<mutex> lock(other.mtx);
        bestPlaintext = other.bestPlaintext;
        bestCiphertext = other.bestCiphertext;
        bestRounds = other.bestRounds;
        bestSimilarity = other.bestSimilarity;
        bestAttempt = other.bestAttempt;
        targetReached.store(other.targetReached.load());
    }
    
    // Funcție pentru mutarea datelor
    void moveFrom(ThreadResult&& other) {
        lock_guard<mutex> lock(other.mtx);
        bestPlaintext = move(other.bestPlaintext);
        bestCiphertext = move(other.bestCiphertext);
        bestRounds = other.bestRounds;
        bestSimilarity = other.bestSimilarity;
        bestAttempt = other.bestAttempt;
        targetReached.store(other.targetReached.load());
    }
};

// Config global
Config config;

// --- Helper Functions ---
string ToHex(const vector<uint8_t>& data) {
    stringstream ss;
    ss << hex << setfill('0');
    for (uint8_t b : data) {
        ss << setw(2) << static_cast<int>(b);
    }
    return ss.str();
}

string ToHexPreview(const vector<uint8_t>& data, int maxBytes = 8) {
    stringstream ss;
    ss << hex << setfill('0');
    int showBytes = min(static_cast<int>(data.size()), maxBytes);
    for (int i = 0; i < showBytes; i++) {
        ss << setw(2) << static_cast<int>(data[i]);
    }
    if (data.size() > static_cast<size_t>(maxBytes)) {
        ss << "...";
    }
    return ss.str();
}

void SecureWipe(vector<uint8_t>& data) {
    if (!data.empty()) {
        memset(data.data(), 0, data.size());
    }
}

void SecureWipeString(string& str) {
    if (!str.empty()) {
        memset(&str[0], 0, str.length());
    }
}

// --- Funcție pentru încărcarea nonce-urilor extrase ---
vector<vector<uint8_t>> LoadNoncesFromFile(const string& filename, size_t targetSize = 0) {
    vector<vector<uint8_t>> nonces;
    ifstream file(filename, ios::binary);
    
    if (!file) {
        cout << "[WARNING] Cannot open nonce file: " << filename << endl;
        return nonces;
    }
    
    file.seekg(0, ios::end);
    size_t fileSize = file.tellg();
    file.seekg(0, ios::beg);
    
    // Fiecare nonce are 16 bytes (dar putem ajusta)
    size_t nonceSize = 16; // Dimensiunea implicită
    size_t numNonces = fileSize / nonceSize;
    
    cout << "[INFO] Found " << numNonces << " nonces in file (" << fileSize << " bytes)" << endl;
    
    for (size_t i = 0; i < numNonces; i++) {
        vector<uint8_t> nonce(nonceSize);
        file.read(reinterpret_cast<char*>(nonce.data()), nonceSize);
        
        // Ajustăm dimensiunea dacă este specificată o dimensiune țintă
        if (targetSize > 0) {
            if (nonce.size() > targetSize) {
                // Trunchiem la dimensiunea țintă
                nonce.resize(targetSize);
            } else if (nonce.size() < targetSize) {
                // Extindem cu zerouri
                nonce.resize(targetSize, 0);
            }
        }
        
        nonces.push_back(nonce);
        
        if (i < 3) { // Afișează primele 3 nonce-uri pentru referință
            cout << "[INFO] Nonce #" << i << ": " << ToHex(nonce) 
                 << " (" << nonce.size() << " bytes)" << endl;
        }
    }
    
    file.close();
    return nonces;
}

// --- GPU Initialization ---
bool InitializeGPU() {
#ifdef USE_CUDA
    int deviceCount;
    cudaError_t err = cudaGetDeviceCount(&deviceCount);
    
    if (err != cudaSuccess || deviceCount == 0) {
        cout << "[INFO] No CUDA devices found, using CPU only" << endl;
        return false;
    }
    
    cudaDeviceProp prop;
    cudaGetDeviceProperties(&prop, config.gpuDeviceId);
    
    cout << "[INFO] CUDA GPU acceleration ENABLED" << endl;
    cout << "[INFO] GPU Device: " << prop.name << endl;
    cout << "[INFO] Compute Capability: " << prop.major << "." << prop.minor << endl;
    cout << "[INFO] Global Memory: " << prop.totalGlobalMem / (1024*1024) << " MB" << endl;
    cout << "[INFO] GPU Batch Size: " << config.gpuBatchSize << endl;
    
    cudaSetDevice(config.gpuDeviceId);
    return true;
#else
    cout << "[INFO] CUDA support not compiled, using CPU only" << endl;
    return false;
#endif
}

// --- Generator ultra-rapid de plaintext (CPU) ---
vector<uint8_t> GenerateFastPlaintext(uint64_t seed, uint64_t attempt) {
    vector<uint8_t> plaintext(32);
    
    mt19937_64 fastGen(seed + attempt * 7919);
    
    for (int i = 0; i < 4; i++) {
        uint64_t val = fastGen();
        memcpy(plaintext.data() + i * 8, &val, 8);
    }
    
    plaintext[0] ^= static_cast<uint8_t>(attempt & 0xFF);
    plaintext[31] ^= static_cast<uint8_t>((attempt >> 8) & 0xFF);
    
    return plaintext;
}

// --- Generator de plaintext batch (CPU multi-thread) ---
vector<vector<uint8_t>> GeneratePlaintextBatch(int batchSize, uint64_t baseSeed) {
    vector<vector<uint8_t>> batch(batchSize);
    
    for (int i = 0; i < batchSize; i++) {
        batch[i] = GenerateFastPlaintext(baseSeed, i);
    }
    
    return batch;
}

// --- ALGORITM SINCRONIZAT ---
bool DeriveKey_Synced(const string& passphrase, const vector<uint8_t>& salt, 
                      uint32_t rounds, vector<uint8_t>& outKey, vector<uint8_t>& outIV) {
    unsigned char buf[SHA512_DIGEST_LENGTH];
    
    EVP_MD_CTX* ctx = EVP_MD_CTX_new();
    if (!ctx) return false;

    if (!EVP_DigestInit_ex(ctx, EVP_sha512(), NULL) ||
        !EVP_DigestUpdate(ctx, passphrase.c_str(), passphrase.length()) ||
        !EVP_DigestUpdate(ctx, salt.data(), salt.size()) ||
        !EVP_DigestFinal_ex(ctx, buf, NULL)) {
        EVP_MD_CTX_free(ctx);
        return false;
    }

    if (rounds > 1) {
        for (uint32_t i = 0; i < rounds - 1; i++) {
            if (!EVP_DigestInit_ex(ctx, EVP_sha512(), NULL) ||
                !EVP_DigestUpdate(ctx, buf, SHA512_DIGEST_LENGTH) ||
                !EVP_DigestFinal_ex(ctx, buf, NULL)) {
                EVP_MD_CTX_free(ctx);
                return false;
            }
        }
    }

    EVP_MD_CTX_free(ctx);

    outKey.assign(buf, buf + 32);
    outIV.assign(buf + 32, buf + 32 + 16);
    
    return true;
}

// --- ALGORITM SINCRONIZAT OPTIMIZAT ---
bool DeriveKey_Synced_Fast(const string& passphrase, const vector<uint8_t>& salt, 
                           uint32_t rounds, vector<uint8_t>& outKey, vector<uint8_t>& outIV) {
    if (rounds <= 1000) {
        EVP_MD_CTX* ctx = EVP_MD_CTX_new();
        if (!ctx) return false;
        
        unsigned char buf[SHA512_DIGEST_LENGTH];
        
        if (!EVP_DigestInit_ex(ctx, EVP_sha512(), NULL) ||
            !EVP_DigestUpdate(ctx, passphrase.c_str(), passphrase.length()) ||
            !EVP_DigestUpdate(ctx, salt.data(), salt.size()) ||
            !EVP_DigestFinal_ex(ctx, buf, NULL)) {
            EVP_MD_CTX_free(ctx);
            return false;
        }
        
        for (uint32_t i = 1; i < rounds; i++) {
            if (!EVP_DigestInit_ex(ctx, EVP_sha512(), NULL) ||
                !EVP_DigestUpdate(ctx, buf, SHA512_DIGEST_LENGTH) ||
                !EVP_DigestFinal_ex(ctx, buf, NULL)) {
                EVP_MD_CTX_free(ctx);
                return false;
            }
        }
        
        EVP_MD_CTX_free(ctx);
        outKey.assign(buf, buf + 32);
        outIV.assign(buf + 32, buf + 32 + 16);
        return true;
    }
    
    return DeriveKey_Synced(passphrase, salt, rounds, outKey, outIV);
}

// --- Derivare cheie batch (multi-thread) ---
vector<pair<vector<uint8_t>, vector<uint8_t>>> DeriveKeyBatch(
    const string& passphrase, 
    const vector<uint8_t>& salt,
    uint32_t rounds,
    int batchSize) {
    
    vector<pair<vector<uint8_t>, vector<uint8_t>>> results(batchSize);
    
    for (int i = 0; i < batchSize; i++) {
        vector<uint8_t> key, iv;
        DeriveKey_Synced_Fast(passphrase, salt, rounds, key, iv);
        results[i] = make_pair(move(key), move(iv));
    }
    
    return results;
}

// --- Criptare AES ---
vector<uint8_t> EncryptAES(const vector<uint8_t>& plaintext, 
                           const vector<uint8_t>& key, const vector<uint8_t>& iv) {
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (!ctx) return {};
    
    vector<uint8_t> ciphertext(plaintext.size() + AES_BLOCK_SIZE);
    int len = 0, ciphertext_len = 0;

    if (1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key.data(), iv.data())) {
        EVP_CIPHER_CTX_free(ctx);
        return {};
    }
    
    if (1 != EVP_EncryptUpdate(ctx, ciphertext.data(), &len, plaintext.data(), plaintext.size())) {
        EVP_CIPHER_CTX_free(ctx);
        return {};
    }
    ciphertext_len = len;
    
    if (1 != EVP_EncryptFinal_ex(ctx, ciphertext.data() + len, &len)) {
        EVP_CIPHER_CTX_free(ctx);
        return {};
    }
    ciphertext_len += len;
    
    ciphertext.resize(ciphertext_len);
    EVP_CIPHER_CTX_free(ctx);
    return ciphertext;
}

// --- Criptare AES Fast ---
vector<uint8_t> EncryptAES_Fast(const vector<uint8_t>& plaintext, 
                                const vector<uint8_t>& key, const vector<uint8_t>& iv) {
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (!ctx) return {};
    
    vector<uint8_t> ciphertext(plaintext.size() + AES_BLOCK_SIZE);
    int len = 0, ciphertext_len = 0;
    
    EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key.data(), iv.data());
    EVP_EncryptUpdate(ctx, ciphertext.data(), &len, plaintext.data(), plaintext.size());
    ciphertext_len = len;
    EVP_EncryptFinal_ex(ctx, ciphertext.data() + len, &len);
    ciphertext_len += len;
    
    ciphertext.resize(ciphertext_len);
    EVP_CIPHER_CTX_free(ctx);
    return ciphertext;
}

// --- Criptare AES Batch (multi-thread) ---
vector<vector<uint8_t>> EncryptAES_Batch(
    const vector<vector<uint8_t>>& plaintexts,
    const vector<pair<vector<uint8_t>, vector<uint8_t>>>& keys) {
    
    vector<vector<uint8_t>> ciphertexts(plaintexts.size());
    
    for (size_t i = 0; i < plaintexts.size(); i++) {
        ciphertexts[i] = EncryptAES_Fast(plaintexts[i], keys[i].first, keys[i].second);
    }
    
    return ciphertexts;
}

// --- Decriptare AES ---
vector<uint8_t> DecryptAES(const vector<uint8_t>& ciphertext, 
                           const vector<uint8_t>& key, const vector<uint8_t>& iv) {
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (!ctx) return {};
    
    vector<uint8_t> plaintext(ciphertext.size());
    int len = 0, plaintext_len = 0;

    if (1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key.data(), iv.data())) {
        EVP_CIPHER_CTX_free(ctx);
        return {};
    }
    
    if (1 != EVP_DecryptUpdate(ctx, plaintext.data(), &len, ciphertext.data(), ciphertext.size())) {
        EVP_CIPHER_CTX_free(ctx);
        return {};
    }
    plaintext_len = len;
    
    if (1 != EVP_DecryptFinal_ex(ctx, plaintext.data() + len, &len)) {
        EVP_CIPHER_CTX_free(ctx);
        return {};
    }
    plaintext_len += len;
    
    plaintext.resize(plaintext_len);
    EVP_CIPHER_CTX_free(ctx);
    return plaintext;
}

// --- Calcul similaritate ---
double CalculateSimilarity(const vector<uint8_t>& a, const vector<uint8_t>& b) {
    if (a.empty() || b.empty()) return 0.0;
    
    size_t minSize = min(a.size(), b.size());
    int identicalBytes = 0;
    
    for (size_t i = 0; i < minSize; i++) {
        if (a[i] == b[i]) {
            identicalBytes++;
        }
    }
    
    return static_cast<double>(identicalBytes) / minSize;
}

// --- Calcul similaritate rapid ---
double CalculateSimilarity_Fast(const vector<uint8_t>& a, const vector<uint8_t>& b) {
    if (a.empty() || b.empty()) return 0.0;
    
    size_t checkSize = min(min(a.size(), b.size()), static_cast<size_t>(16));
    int identicalBytes = 0;
    
    for (size_t i = 0; i < checkSize; i++) {
        if (a[i] == b[i]) identicalBytes++;
    }
    
    return static_cast<double>(identicalBytes) / checkSize;
}

// --- Calcul similaritate batch (multi-thread) ---
vector<double> CalculateSimilarityBatch(
    const vector<vector<uint8_t>>& ciphertexts,
    const vector<uint8_t>& reference) {
    
    vector<double> similarities(ciphertexts.size());
    
    for (size_t i = 0; i < ciphertexts.size(); i++) {
        similarities[i] = CalculateSimilarity_Fast(ciphertexts[i], reference);
    }
    
    return similarities;
}

// --- Funcție worker pentru thread-uri CPU ---
void BruteForceWorker(uint64_t threadId, uint64_t startSeed, 
                      const string& password, const vector<uint8_t>& salt,
                      const vector<uint8_t>& oldCiphertext,
                      ThreadResult& result, atomic<uint64_t>& attemptsCounter,
                      atomic<bool>& stopFlag) {
    
    vector<uint8_t> derivedKey, derivedIV;
    vector<uint8_t> plaintext, ciphertext;
    
    uint32_t localRounds = config.fixedRounds > 0 ? config.fixedRounds : 1;
    uint64_t localAttempt = threadId * 1000000ULL;
    
    while (!stopFlag && !result.targetReached.load()) {
        plaintext = GenerateFastPlaintext(startSeed + localAttempt, localAttempt);
        
        if (!DeriveKey_Synced_Fast(password, salt, localRounds, derivedKey, derivedIV)) {
            localAttempt++;
            continue;
        }
        
        ciphertext = EncryptAES_Fast(plaintext, derivedKey, derivedIV);
        if (ciphertext.empty()) {
            localAttempt++;
            continue;
        }
        
        double similarity = CalculateSimilarity_Fast(ciphertext, oldCiphertext);
        
        {
            lock_guard<mutex> lock(result.mtx);
            if (similarity > result.bestSimilarity) {
                result.bestSimilarity = similarity;
                result.bestAttempt = localAttempt;
                result.bestPlaintext = plaintext;
                result.bestCiphertext = ciphertext;
                result.bestRounds = localRounds;
                
                if (similarity >= config.targetSimilarity) {
                    result.targetReached = true;
                    stopFlag = true;
                    break;
                }
            }
        }
        
        attemptsCounter++;
        localAttempt++;
        
        if (localAttempt % 10000 == 0) {
            this_thread::sleep_for(chrono::microseconds(10));
        }
    }
}

// --- Display Functions ---
void DisplayProgressOptimized(uint64_t totalAttempts, double bestSimilarity,
                             chrono::seconds elapsedTime, bool showDetails = false) {
    double speed = (elapsedTime.count() > 0) ? 
                   static_cast<double>(totalAttempts) / elapsedTime.count() : 0;
    
    cout << "\r";
    cout << " Attempts: " << setw(12) << totalAttempts
         << " | Speed: " << setw(8) << static_cast<int>(speed) << "/s"
         << " | Best: " << fixed << setprecision(2) << setw(6) 
         << (bestSimilarity * 100) << "%"
         << " | Time: " << setw(6) << elapsedTime.count() << "s";
    
    if (showDetails) {
        cout << " | Target: " << (config.targetSimilarity * 100) << "%";
    }
    
    cout << "          ";
    cout.flush();
}

void DisplayHeader() {
    cout << "============================================================" << endl;
    cout << "                  MKey Injector ULTRA-FAST                  " << endl;
    cout << "              with Extracted Nonce Support v2.0             " << endl;
    cout << "                    Multi-CPU/GPU Version                   " << endl;
    cout << "============================================================" << endl;
}

void DisplayConfig() {
    cout << "\nConfiguration:" << endl;
    cout << "- Wallet: " << config.walletFile << endl;
    cout << "- Password: " << string(config.password.length(), '*') << endl;
    cout << "- Rounds: " << config.fixedRounds << endl;
    cout << "- Threads: " << config.numThreads << endl;
    cout << "- GPU: " << (config.useGPU ? "YES" : "NO") << endl;
    cout << "- Brute force: " << (config.enableBruteForce ? "YES" : "NO") << endl;
    
    if (config.enableBruteForce) {
        cout << "- Target similarity: " << config.targetSimilarity * 100 << "%" << endl;
        cout << "- Max attempts: " << (config.bruteForceMaxAttempts == 0 ? 
                                      "UNLIMITED" : to_string(config.bruteForceMaxAttempts)) << endl;
    }
    
    if (config.useExtractedNonces) {
        cout << "- Extracted nonces: YES (file: " << config.nonceFile << ")" << endl;
        if (config.testAllNonces) {
            cout << "- Test all nonces: YES" << endl;
        } else {
            cout << "- Selected nonce index: " << config.selectedNonceIndex << endl;
        }
    }
    
    if (config.ultraFastMode) {
        cout << "- Mode: ULTRA-FAST (maximum performance)" << endl;
    } else if (config.fastMode) {
        cout << "- Mode: FAST (optimized)" << endl;
    }
    
    cout << "============================================================" << endl;
}

void DisplayResult(const vector<uint8_t>& newCiphertext,
                   const vector<uint8_t>& saltOrNonce,
                   uint32_t rounds,
                   double similarity,
                   uint64_t attempts,
                   chrono::milliseconds duration,
                   bool success = false,
                   bool isNonce = false) {
    
    cout << "\n\n" << string(60, '=') << endl;
    cout << "                       RESULT                         " << endl;
    cout << string(60, '=') << endl;
    
    cout << " Status:          " << (success ? "SUCCESS" : "BEST EFFORT") << endl;
    cout << " Attempts:        " << attempts << endl;
    cout << " Time:            " << duration.count() / 1000.0 << " seconds" << endl;
    
    double speed = (duration.count() > 0) ? 
                   static_cast<double>(attempts) / (duration.count() / 1000.0) : 0;
    cout << " Speed:           " << static_cast<int>(speed) << " attempts/second" << endl;
    
    cout << " Similarity:      " << fixed << setprecision(4) << (similarity * 100) << "%" << endl;
    
    if (config.enableBruteForce) {
        cout << " Target:          " << (config.targetSimilarity * 100) << "%" << endl;
        if (similarity >= config.targetSimilarity) {
            cout << " Target Reached:  YES" << endl;
        }
    }
    
    cout << " New Rounds:      " << rounds << endl;
    cout << " " << (isNonce ? "Nonce" : "Salt") << " used:       " 
         << (isNonce ? "EXTRACTED NONCE" : "ORIGINAL SALT") << endl;
    cout << " Value:           " << ToHex(saltOrNonce) << endl;
    cout << " New Ciphertext:  " << endl;
    if (config.showFullCiphertext) {
        cout << "   " << ToHex(newCiphertext) << endl;
    } else {
        cout << "   " << ToHexPreview(newCiphertext, 64) << endl;
    }
    
    cout << string(60, '=') << endl;
}

// --- Brute Force CPU Functions ---
bool BruteForceCPU(const string& password,
                   const vector<uint8_t>& salt,
                   const vector<uint8_t>& oldCiphertext,
                   ThreadResult& resultOut) {
    
    auto startTime = chrono::high_resolution_clock::now();
    
    if (config.enableBruteForce && config.numThreads > 1) {
        // Parallel CPU mode
        cout << "\n[CPU Parallel Mode - " << config.numThreads << " threads]" << endl;
        
        vector<thread> threads;
        vector<unique_ptr<ThreadResult>> threadResults(config.numThreads);
        for (auto& tr : threadResults) {
            tr = make_unique<ThreadResult>();
        }
        
        atomic<uint64_t> totalAttempts{0};
        atomic<bool> stopFlag{false};
        
        // Start worker threads
        for (int i = 0; i < config.numThreads; i++) {
            uint64_t threadSeed = chrono::duration_cast<chrono::nanoseconds>(
                chrono::high_resolution_clock::now().time_since_epoch()).count() + i * 1000;
            
            threads.emplace_back([i, threadSeed, &password, &salt, &oldCiphertext,
                                 &threadResults, &totalAttempts, &stopFlag]() {
                
                vector<uint8_t> derivedKey, derivedIV;
                vector<uint8_t> plaintext, ciphertext;
                
                uint32_t localRounds = config.fixedRounds > 0 ? config.fixedRounds : 1;
                uint64_t localAttempt = i * 1000000ULL;
                
                while (!stopFlag && !threadResults[i]->targetReached.load()) {
                    plaintext = GenerateFastPlaintext(threadSeed + localAttempt, localAttempt);
                    
                    if (!DeriveKey_Synced_Fast(password, salt, localRounds, derivedKey, derivedIV)) {
                        localAttempt++;
                        continue;
                    }
                    
                    ciphertext = EncryptAES_Fast(plaintext, derivedKey, derivedIV);
                    if (ciphertext.empty()) {
                        localAttempt++;
                        continue;
                    }
                    
                    double similarity = CalculateSimilarity_Fast(ciphertext, oldCiphertext);
                    
                    {
                        lock_guard<mutex> lock(threadResults[i]->mtx);
                        if (similarity > threadResults[i]->bestSimilarity) {
                            threadResults[i]->bestSimilarity = similarity;
                            threadResults[i]->bestAttempt = localAttempt;
                            threadResults[i]->bestPlaintext = plaintext;
                            threadResults[i]->bestCiphertext = ciphertext;
                            threadResults[i]->bestRounds = localRounds;
                            
                            if (similarity >= config.targetSimilarity) {
                                threadResults[i]->targetReached = true;
                                stopFlag = true;
                                break;
                            }
                        }
                    }
                    
                    totalAttempts++;
                    localAttempt++;
                    
                    if (localAttempt % 10000 == 0) {
                        this_thread::sleep_for(chrono::microseconds(10));
                    }
                }
            });
        }
        
        // Monitor progress
        int lastDisplay = 0;
        while (!stopFlag) {
            this_thread::sleep_for(chrono::milliseconds(100));
            
            double globalBest = 0.0;
            bool targetReached = false;
            
            for (int i = 0; i < config.numThreads; i++) {
                if (threadResults[i]->bestSimilarity > globalBest) {
                    globalBest = threadResults[i]->bestSimilarity;
                }
                if (threadResults[i]->targetReached.load()) {
                    targetReached = true;
                    stopFlag = true;
                    break;
                }
            }
            
            auto currentTime = chrono::high_resolution_clock::now();
            auto elapsed = chrono::duration_cast<chrono::seconds>(currentTime - startTime);
            
            if (elapsed.count() > lastDisplay) {
                DisplayProgressOptimized(totalAttempts.load(), globalBest, elapsed, true);
                lastDisplay = elapsed.count();
                
                if (globalBest >= config.targetSimilarity && !targetReached) {
                    stopFlag = true;
                    cout << "\n\n[OK] Target reached!" << endl;
                    break;
                }
            }
            
            // Check max attempts
            if (config.bruteForceMaxAttempts > 0 && 
                totalAttempts.load() >= config.bruteForceMaxAttempts) {
                cout << "\n\n[!] Max attempts reached: " << totalAttempts.load() << endl;
                stopFlag = true;
                break;
            }
        }
        
        // Wait for threads to finish
        for (auto& t : threads) {
            if (t.joinable()) t.join();
        }
        
        // Find best result
        ThreadResult* bestResult = threadResults[0].get();
        for (int i = 1; i < config.numThreads; i++) {
            if (threadResults[i]->bestSimilarity > bestResult->bestSimilarity) {
                bestResult = threadResults[i].get();
            }
        }
        
        // Copy best result to output using copyFrom
        resultOut.copyFrom(*bestResult);
        
        auto endTime = chrono::high_resolution_clock::now();
        auto duration = chrono::duration_cast<chrono::milliseconds>(endTime - startTime);
        
        DisplayResult(resultOut.bestCiphertext, salt, resultOut.bestRounds,
                     resultOut.bestSimilarity, totalAttempts.load(), duration,
                     resultOut.bestSimilarity >= config.targetSimilarity, false);
        
        return (resultOut.bestSimilarity >= config.targetSimilarity);
        
    } else {
        // Sequential CPU mode
        cout << "\n[CPU Sequential Mode]" << endl;
        
        uint64_t attempts = 0;
        double bestSimilarity = 0.0;
        vector<uint8_t> bestCiphertext, bestPlaintext;
        uint32_t bestRounds = config.fixedRounds;
        
        auto lastUpdate = chrono::high_resolution_clock::now();
        
        while (true) {
            attempts++;
            
            vector<uint8_t> plaintext = GenerateFastPlaintext(
                chrono::duration_cast<chrono::nanoseconds>(
                    chrono::high_resolution_clock::now().time_since_epoch()).count(),
                attempts);
            
            vector<uint8_t> derivedKey, derivedIV;
            if (!DeriveKey_Synced_Fast(password, salt, config.fixedRounds, derivedKey, derivedIV)) {
                continue;
            }
            
            vector<uint8_t> ciphertext = EncryptAES_Fast(plaintext, derivedKey, derivedIV);
            if (ciphertext.empty()) continue;
            
            double similarity = CalculateSimilarity_Fast(ciphertext, oldCiphertext);
            
            if (similarity > bestSimilarity) {
                bestSimilarity = similarity;
                bestCiphertext = ciphertext;
                bestPlaintext = plaintext;
                bestRounds = config.fixedRounds;
                
                auto currentTime = chrono::high_resolution_clock::now();
                auto elapsed = chrono::duration_cast<chrono::seconds>(currentTime - startTime);
                
                if (chrono::duration_cast<chrono::milliseconds>(
                    currentTime - lastUpdate).count() > 500) {
                    DisplayProgressOptimized(attempts, bestSimilarity, elapsed);
                    lastUpdate = currentTime;
                }
                
                if (config.enableBruteForce && similarity >= config.targetSimilarity) {
                    cout << "\n\n[OK] Target reached after " << attempts << " attempts!" << endl;
                    break;
                }
            }
            
            if (!config.enableBruteForce && attempts >= 100) {
                break;
            }
            
            if (config.enableBruteForce && config.bruteForceMaxAttempts > 0 && 
                attempts >= config.bruteForceMaxAttempts) {
                cout << "\n\n[!] Max attempts reached: " << attempts << endl;
                break;
            }
        }
        
        auto endTime = chrono::high_resolution_clock::now();
        auto duration = chrono::duration_cast<chrono::milliseconds>(endTime - startTime);
        
        DisplayResult(bestCiphertext, salt, bestRounds, bestSimilarity, 
                     attempts, duration, bestSimilarity >= config.targetSimilarity, false);
        
        // Copy to output manually
        {
            lock_guard<mutex> lock(resultOut.mtx);
            resultOut.bestCiphertext = bestCiphertext;
            resultOut.bestPlaintext = bestPlaintext;
            resultOut.bestRounds = bestRounds;
            resultOut.bestSimilarity = bestSimilarity;
            resultOut.bestAttempt = attempts;
            resultOut.targetReached.store(bestSimilarity >= config.targetSimilarity);
        }
        
        return (bestSimilarity >= config.targetSimilarity);
    }
}

// --- Brute Force GPU Functions (complet pe GPU) ---
bool BruteForceGPU(const string& password,
                   const vector<uint8_t>& salt,
                   const vector<uint8_t>& oldCiphertext,
                   ThreadResult& resultOut) {
#ifdef USE_CUDA
    auto startTime = chrono::high_resolution_clock::now();
    
    // ========== VERIFICARE CRITICĂ ADĂUGATĂ ==========
    // GPU-ul poate genera ciphertext-uri de maxim 48 de bytes (datorită limitărilor din kernel)
    // Dacă ciphertext-ul original este mai lung, similaritatea maximă este limitată
    size_t maxGpuCiphertextLen = 48; // AES-CBC cu plaintext de 32 bytes + padding
    if (oldCiphertext.size() > maxGpuCiphertextLen) {
        double maxPossibleSimilarity = (double)maxGpuCiphertextLen / oldCiphertext.size();
        cout << "\n[GPU WARNING] Ciphertext-ul original are " << oldCiphertext.size() 
             << " bytes, dar GPU generează doar " << maxGpuCiphertextLen << " bytes." << endl;
        cout << "[GPU WARNING] Similaritatea maximă posibilă: " 
             << fixed << setprecision(2) << (maxPossibleSimilarity * 100) << "%" << endl;
        
        if (config.targetSimilarity > maxPossibleSimilarity) {
            cout << "[GPU ERROR] Target-ul de " << (config.targetSimilarity * 100) 
                 << "% este IMPOSIBIL de atins cu GPU!" << endl;
            cout << "[GPU ERROR] Reduțeți target-ul sau folosiți modul CPU." << endl;
            return false;
        }
    }
    // ================================================
    
    cout << "\n[GPU Full Mode - 100% GPU operations]" << endl;
    cout << "Running " << config.gpuBatchSize << " attempts per batch" << endl;
    
    uint64_t totalAttempts = 0;
    uint64_t batchCount = 0;
    bool targetReached = false;
    
    cout << "[GPU] Starting GPU mining with target similarity " << (config.targetSimilarity * 100) << "%" << endl;
    
    // Loop infinit până la target sau până când este oprit
    while (!targetReached) {
        batchCount++;
        
        // Calculăm câte încercări să facem în acest batch
        uint64_t attemptsThisBatch = config.gpuBatchSize;
        
        // Dacă avem limită de încercări, ajustăm
        if (config.bruteForceMaxAttempts > 0) {
            uint64_t remaining = config.bruteForceMaxAttempts - totalAttempts;
            if (remaining <= 0) break; // Am atins limita
            
            if (remaining < attemptsThisBatch) {
                attemptsThisBatch = remaining;
            }
        }
        
        if (attemptsThisBatch == 0) break;
        
        cout << "\n[GPU] Batch " << batchCount << ": " << attemptsThisBatch << " attempts (Total: " << totalAttempts << ")" << endl;
        
        // Rulează GPU mining pentru acest batch
        GPUResult gpuResult = runGPUMining(
            oldCiphertext,
            salt,
            password,
            config.fixedRounds,
            attemptsThisBatch,
            config.targetSimilarity
        );
        
        // Actualizează totalul
        totalAttempts += attemptsThisBatch;
        
        // Procesează rezultatele
        if (gpuResult.bestSimilarity > resultOut.bestSimilarity) {
            lock_guard<mutex> lock(resultOut.mtx);
            resultOut.bestSimilarity = gpuResult.bestSimilarity;
            resultOut.bestAttempt = totalAttempts; // Ultimul index
            resultOut.bestPlaintext = gpuResult.bestPlaintext;
            resultOut.bestCiphertext = gpuResult.bestCiphertext;
            resultOut.bestRounds = config.fixedRounds;
            
            if (gpuResult.bestSimilarity >= config.targetSimilarity) {
                resultOut.targetReached.store(true);
                targetReached = true;
            }
        }
        
        // Afișează progresul
        auto currentTime = chrono::high_resolution_clock::now();
        auto elapsed = chrono::duration_cast<chrono::seconds>(currentTime - startTime);
        
        DisplayProgressOptimized(totalAttempts, resultOut.bestSimilarity, elapsed, true);
        
        // Verifică dacă am atins targetul
        if (resultOut.bestSimilarity >= config.targetSimilarity) {
            cout << "\n\n[GPU] Target similarity reached!" << endl;
            break;
        }
        
        // Verifică dacă am atins limita de încercări
        if (config.bruteForceMaxAttempts > 0 && totalAttempts >= config.bruteForceMaxAttempts) {
            cout << "\n\n[GPU] Max attempts reached: " << totalAttempts << endl;
            break;
        }
        
        // Pauză mică pentru a nu încărca GPU-ul 100% continuu (opțional)
        this_thread::sleep_for(chrono::milliseconds(10));
    }
    
    auto endTime = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::milliseconds>(endTime - startTime);
    
    DisplayResult(resultOut.bestCiphertext, salt, resultOut.bestRounds,
                 resultOut.bestSimilarity, totalAttempts, duration,
                 resultOut.bestSimilarity >= config.targetSimilarity, false);
    
    return (resultOut.bestSimilarity >= config.targetSimilarity);
#else
    cout << "[WARNING] CUDA not available, falling back to CPU" << endl;
    return BruteForceCPU(password, salt, oldCiphertext, resultOut);
#endif
}

// --- Main Brute Force Function (decide CPU/GPU) ---
bool BruteForce(const string& password,
                const vector<uint8_t>& salt,
                const vector<uint8_t>& oldCiphertext,
                ThreadResult& resultOut,
                bool isNonce = false) {
    
    // Decide dacă să folosească GPU sau CPU
    if (config.useGPU) {
        return BruteForceGPU(password, salt, oldCiphertext, resultOut);
    } else {
        return BruteForceCPU(password, salt, oldCiphertext, resultOut);
    }
}

// --- Test All Nonces Function ---
bool TestAllNonces(const string& password,
                   const vector<vector<uint8_t>>& nonces,
                   const vector<uint8_t>& oldCiphertext,
                   ThreadResult& bestOverallResult) {
    
    cout << "\n[INFO] Testing all " << nonces.size() << " extracted nonces..." << endl;
    
    double bestOverallSimilarity = 0.0;
    size_t bestNonceIndex = 0;
    bool targetReached = false;
    
    for (size_t i = 0; i < nonces.size(); i++) {
        cout << "\n[TESTING] Nonce #" << i << " of " << nonces.size() 
             << ": " << ToHexPreview(nonces[i], 8) << endl;
        
        ThreadResult currentResult;
        bool reached = BruteForce(password, nonces[i], oldCiphertext, currentResult, true);
        
        double currentSimilarity;
        {
            lock_guard<mutex> lock(currentResult.mtx);
            currentSimilarity = currentResult.bestSimilarity;
        }
        
        if (currentSimilarity > bestOverallSimilarity) {
            bestOverallSimilarity = currentSimilarity;
            bestNonceIndex = i;
            // Folosește copyFrom în loc de operator= pentru a copia datele
            bestOverallResult.copyFrom(currentResult);
            
            cout << "[BEST SO FAR] Nonce #" << i 
                 << " similarity: " << (bestOverallSimilarity * 100) << "%" << endl;
        }
        
        if (reached) {
            cout << "[SUCCESS] Target reached with nonce #" << i << endl;
            targetReached = true;
            break;
        }
        
        // Dacă avem limită de încercări, verificăm
        if (config.bruteForceMaxAttempts > 0) {
            lock_guard<mutex> lock(bestOverallResult.mtx);
            if (bestOverallResult.bestAttempt >= config.bruteForceMaxAttempts) {
                cout << "[INFO] Max attempts reached for this nonce" << endl;
            }
        }
    }
    
    cout << "\n[BEST NONCE] #" << bestNonceIndex 
         << " (" << ToHexPreview(nonces[bestNonceIndex], 8) << ")"
         << " with similarity: " << (bestOverallSimilarity * 100) << "%" << endl;
    
    return targetReached;
}

// --- Main Function ---
int main(int argc, char* argv[]) {
    ERR_load_crypto_strings();
    OpenSSL_add_all_algorithms();
    
    DisplayHeader();
    
    if (argc < 2) {
        cerr << "\nUsage: " << argv[0] << " [wallet.dat] [options]" << endl;
        cerr << "\nOptions:" << endl;
        cerr << "  --password <pass>        : Wallet password (default: 123)" << endl;
        cerr << "  --bruteforce, -b         : Enable brute force mode" << endl;
        cerr << "  --similarity <val>       : Set target similarity (0.0-1.0)" << endl;
        cerr << "  --rounds <N>             : Set fixed number of rounds (1 for max speed)" << endl;
        cerr << "  --threads <N>            : Number of CPU threads (default: 4)" << endl;
        cerr << "  --gpu, --cuda            : Enable GPU acceleration" << endl;
        cerr << "  --gpu-device <id>        : GPU device ID (default: 0)" << endl;
        cerr << "  --batch-size <size>      : GPU batch size (default: 65536)" << endl;
        cerr << "  --ultrafast              : Ultra-fast mode (rounds=1, max optimizations)" << endl;
        cerr << "  --fast                   : Fast mode (rounds=1)" << endl;
        cerr << "  --full                   : Show full ciphertext" << endl;
        cerr << "  --keep-salt              : Keep original salt" << endl;
        cerr << "  --max-attempts <N>       : Maximum attempts (0 = unlimited)" << endl;
        cerr << "  --nonce-file <file>      : File with extracted nonces (16 bytes each)" << endl;
        cerr << "  --nonce-index <index>    : Index of nonce to use (default: 0)" << endl;
        cerr << "  --test-all-nonces        : Test all extracted nonces" << endl;
        cerr << "  --allow-different-salt-size : Allow using nonces with different size than original salt" << endl;
        cerr << "  --help, -h               : Show this help message" << endl;
        
        cerr << "\nExamples:" << endl;
        cerr << "  " << argv[0] << " wallet.dat --ultrafast --bruteforce --gpu" << endl;
        cerr << "  " << argv[0] << " wallet.dat --rounds 1 --threads 8 --gpu" << endl;
        cerr << "  " << argv[0] << " wallet.dat --password mypass --similarity 0.8 --gpu" << endl;
        cerr << "  " << argv[0] << " wallet.dat --fast --bruteforce --full --gpu" << endl;
        cerr << "  " << argv[0] << " wallet.dat --gpu --batch-size 131072 --gpu-device 0" << endl;
        cerr << "  " << argv[0] << " wallet.dat --nonce-file extracted_nonces.bin --bruteforce" << endl;
        cerr << "  " << argv[0] << " wallet.dat --nonce-file all_nonces.bin --test-all-nonces" << endl;
        cerr << "  " << argv[0] << " wallet.dat --nonce-file nonces.raw --nonce-index 3 --gpu" << endl;
        return 1;
    }
    
    config.walletFile = argv[1];
    
    // Parse command line arguments
    for (int i = 2; i < argc; i++) {
        string arg = argv[i];
        
        if (arg == "--help" || arg == "-h") {
            // Help already shown
            return 0;
        }
        else if (arg == "--password" && i + 1 < argc) {
            config.password = argv[++i];
            cout << "Password set: " << string(config.password.length(), '*') << endl;
        }
        else if (arg == "--bruteforce" || arg == "-b") {
            config.enableBruteForce = true;
            cout << "Brute Force: ENABLED" << endl;
        }
        else if (arg == "--similarity" && i + 1 < argc) {
            config.targetSimilarity = stod(argv[++i]);
            if (config.targetSimilarity < 0.0 || config.targetSimilarity > 1.0) {
                cerr << "Error: Similarity must be between 0.0 and 1.0" << endl;
                return 1;
            }
            cout << "Target similarity: " << config.targetSimilarity * 100 << "%" << endl;
        }
        else if (arg == "--rounds" && i + 1 < argc) {
            config.fixedRounds = stoi(argv[++i]);
            if (config.fixedRounds < 1) {
                cerr << "Error: Rounds must be at least 1" << endl;
                return 1;
            }
            cout << "Fixed rounds: " << config.fixedRounds << endl;
        }
        else if (arg == "--threads" && i + 1 < argc) {
            config.numThreads = stoi(argv[++i]);
            if (config.numThreads < 1) {
                cerr << "Error: Threads must be at least 1" << endl;
                return 1;
            }
            cout << "CPU threads: " << config.numThreads << endl;
        }
        else if (arg == "--gpu" || arg == "--cuda") {
            config.useGPU = true;
            cout << "GPU acceleration: ENABLED" << endl;
        }
        else if (arg == "--gpu-device" && i + 1 < argc) {
            config.gpuDeviceId = stoi(argv[++i]);
            cout << "GPU device ID: " << config.gpuDeviceId << endl;
        }
        else if (arg == "--batch-size" && i + 1 < argc) {
            config.gpuBatchSize = stoull(argv[++i]);
            cout << "GPU batch size: " << config.gpuBatchSize << endl;
        }
        else if (arg == "--ultrafast") {
            config.ultraFastMode = true;
            config.fixedRounds = 1;
            config.enableBruteForce = true;
            config.numThreads = thread::hardware_concurrency();
            if (config.numThreads == 0) config.numThreads = 4;
            config.useGPU = true;  // Auto-enable GPU in ultra-fast mode
            cout << "ULTRA-FAST mode: ENABLED" << endl;
            cout << "  - Rounds: 1" << endl;
            cout << "  - Threads: " << config.numThreads << endl;
            cout << "  - GPU: AUTO-ENABLED" << endl;
        }
        else if (arg == "--fast") {
            config.fastMode = true;
            config.fixedRounds = 1;
            config.enableBruteForce = true;
            cout << "FAST mode: ENABLED (rounds=1)" << endl;
        }
        else if (arg == "--full") {
            config.showFullCiphertext = true;
            config.fullOutput = true;
            cout << "Full output: ENABLED" << endl;
        }
        else if (arg == "--keep-salt") {
            config.useFixedSalt = true;
            cout << "Using original salt: YES" << endl;
        }
        else if (arg == "--max-attempts" && i + 1 < argc) {
            config.bruteForceMaxAttempts = stoull(argv[++i]);
            cout << "Max attempts: " << config.bruteForceMaxAttempts << endl;
        }
        else if (arg == "--nonce-file" && i + 1 < argc) {
            config.nonceFile = argv[++i];
            config.useExtractedNonces = true;
            cout << "Nonce file: " << config.nonceFile << endl;
        }
        else if (arg == "--nonce-index" && i + 1 < argc) {
            config.selectedNonceIndex = stoul(argv[++i]);
            cout << "Selected nonce index: " << config.selectedNonceIndex << endl;
        }
        else if (arg == "--test-all-nonces") {
            config.testAllNonces = true;
            cout << "Test all nonces: ENABLED" << endl;
        }
        else if (arg == "--allow-different-salt-size") {
            config.preserveOriginalSaltSize = false;
            cout << "Allowing different salt sizes: YES" << endl;
        }
        else {
            cerr << "Unknown option: " << arg << endl;
            cerr << "Use --help for usage information" << endl;
            return 1;
        }
    }
    
    // Apply fast mode if specified
    if (config.fastMode) {
        config.fixedRounds = 1;
        config.enableBruteForce = true;
    }
    
    if (!filesystem::exists(config.walletFile)) {
        cerr << "Error: File " << config.walletFile << " does not exist." << endl;
        return 1;
    }
    
    if (config.ultraFastMode && config.fixedRounds > 1) {
        config.fixedRounds = 1;
    }
    
    DisplayConfig();
    
    // Initialize GPU if requested
    if (config.useGPU) {
        if (!InitializeGPU()) {
            cout << "[WARNING] Falling back to CPU mode" << endl;
            config.useGPU = false;
        }
    }
    
    // Load extracted nonces if specified (doar citire inițială)
    vector<vector<uint8_t>> extractedNonces;
    if (config.useExtractedNonces && !config.nonceFile.empty()) {
        extractedNonces = LoadNoncesFromFile(config.nonceFile);
        
        if (extractedNonces.empty()) {
            cout << "[WARNING] No nonces loaded, falling back to original salt" << endl;
            config.useExtractedNonces = false;
        } else if (config.selectedNonceIndex >= extractedNonces.size()) {
            cout << "[WARNING] Invalid nonce index " << config.selectedNonceIndex 
                 << ", using first nonce (0)" << endl;
            config.selectedNonceIndex = 0;
        }
    }
    
    DbEnv env(0);
    Db* pdb = nullptr;
    Dbc* cursorp = nullptr;
    bool success = false;
    
    // Declare finalResult BEFORE try block so it's accessible throughout main()
    ThreadResult finalResult;
    vector<uint8_t> currentNonceOrSalt;
    bool usingNonce = false;
    size_t originalSaltSize = 0;
    
    try {
        env.set_error_stream(&cerr);
        env.open(".", DB_CREATE | DB_INIT_MPOOL | DB_PRIVATE, 0);
        
        pdb = new Db(&env, 0);
        pdb->open(nullptr, config.walletFile.c_str(), "main", DB_BTREE, 0, 0);
        
        pdb->cursor(nullptr, &cursorp, 0);
        
        Dbt key, data;
        int ret;
        bool found = false;
        
        while ((ret = cursorp->get(&key, &data, DB_NEXT)) == 0) {
            vector<uint8_t> keyVec(static_cast<uint8_t*>(key.get_data()), 
                                   static_cast<uint8_t*>(key.get_data()) + key.get_size());
            
            if (keyVec.size() >= 5 && keyVec[0] == 4) {
                string type(keyVec.begin() + 1, keyVec.begin() + 5);
                if (type == "mkey") {
                    found = true;
                    cout << "\n[OK] MKey found in wallet!" << endl;
                    
                    vector<uint8_t> valVec(static_cast<uint8_t*>(data.get_data()), 
                                           static_cast<uint8_t*>(data.get_data()) + data.get_size());
                    
                    size_t offset = 0;
                    
                    uint8_t oldKeyLen = valVec[offset++];
                    vector<uint8_t> oldEncryptedKey(valVec.begin() + offset, 
                                                    valVec.begin() + offset + oldKeyLen);
                    offset += oldKeyLen;
                    
                    uint8_t saltLen = valVec[offset++];
                    vector<uint8_t> extractedSalt(valVec.begin() + offset, 
                                                  valVec.begin() + offset + saltLen);
                    offset += saltLen;
                    
                    originalSaltSize = saltLen;
                    
                    uint32_t oldMethod, oldRounds;
                    memcpy(&oldMethod, valVec.data() + offset, 4); offset += 4;
                    memcpy(&oldRounds, valVec.data() + offset, 4); offset += 4;
                    
                    vector<uint8_t> extraData;
                    if (offset < valVec.size()) {
                        extraData.assign(valVec.begin() + offset, valVec.end());
                    }
                    
                    cout << "\n[ORIGINAL INFO]" << endl;
                    cout << "- Ciphertext: " << (config.showFullCiphertext ? 
                        ToHex(oldEncryptedKey) : ToHexPreview(oldEncryptedKey, 32)) << endl;
                    cout << "- Salt: " << ToHex(extractedSalt) << endl;
                    cout << "- Original rounds: " << oldRounds << endl;
                    cout << "- Ciphertext length: " << oldEncryptedKey.size() << " bytes" << endl;
                    cout << "- Salt length: " << (int)saltLen << " bytes" << endl;
                    
                    cout << "\n[GENERATION SETTINGS]" << endl;
                    cout << "- New rounds: " << config.fixedRounds << endl;
                    cout << "- Device: " << (config.useGPU ? "GPU" : "CPU") << endl;
                    
                    // Ajustează nonce-urile la dimensiunea salt-ului original DUPĂ ce știm dimensiunea
                    if (config.useExtractedNonces && !extractedNonces.empty()) {
                        cout << "[INFO] Adjusting nonces to match original salt size: " << originalSaltSize << " bytes" << endl;
                        for (auto& nonce : extractedNonces) {
                            if (nonce.size() > originalSaltSize) {
                                // Trunchiem la dimensiunea originală
                                nonce.resize(originalSaltSize);
                            } else if (nonce.size() < originalSaltSize) {
                                // Extindem cu zerouri
                                nonce.resize(originalSaltSize, 0);
                            }
                        }
                        
                        // Afișează nonce-urile ajustate
                        for (size_t i = 0; i < min(extractedNonces.size(), static_cast<size_t>(3)); i++) {
                            cout << "[INFO] Adjusted nonce #" << i << ": " 
                                 << ToHex(extractedNonces[i]) << " (" 
                                 << extractedNonces[i].size() << " bytes)" << endl;
                        }
                    }
                    
                    bool targetReached = false;
                    
                    // Decide what to use: extracted nonce or original salt
                    if (config.useExtractedNonces && !extractedNonces.empty()) {
                        if (config.testAllNonces) {
                            cout << "- Mode: TESTING ALL EXTRACTED NONCES (" 
                                 << extractedNonces.size() << " nonces)" << endl;
                            
                            targetReached = TestAllNonces(config.password, extractedNonces, 
                                                         oldEncryptedKey, finalResult);
                            
                            // Use the best nonce found
                            usingNonce = true;
                            currentNonceOrSalt = extractedNonces[0];
                        } else {
                            cout << "- Using extracted nonce #" << config.selectedNonceIndex << endl;
                            cout << "- Nonce: " << ToHex(extractedNonces[config.selectedNonceIndex]) 
                                 << " (" << extractedNonces[config.selectedNonceIndex].size() << " bytes)" << endl;
                            
                            currentNonceOrSalt = extractedNonces[config.selectedNonceIndex];
                            usingNonce = true;
                            
                            targetReached = BruteForce(config.password, currentNonceOrSalt, 
                                                      oldEncryptedKey, finalResult, true);
                        }
                    } else {
                        cout << "- Using original salt" << endl;
                        cout << "- Salt: " << ToHex(extractedSalt) << endl;
                        
                        currentNonceOrSalt = extractedSalt;
                        usingNonce = false;
                        
                        targetReached = BruteForce(config.password, currentNonceOrSalt, 
                                                  oldEncryptedKey, finalResult, false);
                    }
                    
                    // Update wallet.dat if we have a valid result
                    if (!finalResult.bestCiphertext.empty()) {
                        // VERIFICĂ DIMENSIUNILE CRITICE pentru a preveni coruperea
                        cout << "\n[VALIDARE STRUCTURĂ]" << endl;
                        cout << "- Ciphertext generat: " << finalResult.bestCiphertext.size() << " bytes" << endl;
                        cout << "- Ciphertext original: " << oldEncryptedKey.size() << " bytes" << endl;
                        cout << "- Salt/Nonce folosit: " << currentNonceOrSalt.size() << " bytes" << endl;
                        cout << "- Salt original: " << extractedSalt.size() << " bytes" << endl;
                        
                        // Verifică dacă dimensiunile sunt compatibile
                        if (finalResult.bestCiphertext.size() != oldEncryptedKey.size()) {
                            cerr << "[EROARE CRITICĂ] Ciphertext-ul generat (" 
                                 << finalResult.bestCiphertext.size() 
                                 << " bytes) nu are aceeași dimensiune ca cel original (" 
                                 << oldEncryptedKey.size() << " bytes)!" << endl;
                            cerr << "[EROARE] Wallet-ul NU va fi actualizat pentru a preveni coruperea." << endl;
                            break;
                        }
                        
                        // Verificarea dimensiunii salt-ului - acum permite diferite dimensiuni dacă config.preserveOriginalSaltSize este false
                        if (config.preserveOriginalSaltSize && currentNonceOrSalt.size() != extractedSalt.size()) {
                            cerr << "[EROARE CRITICĂ] Salt-ul/Nonce-ul (" 
                                 << currentNonceOrSalt.size() 
                                 << " bytes) nu are aceeași dimensiune ca cel original (" 
                                 << extractedSalt.size() << " bytes)!" << endl;
                            cerr << "[EROARE] Wallet-ul NU va fi actualizat pentru a preveni coruperea." << endl;
                            cerr << "[SUGESTIE] Folosește opțiunea --allow-different-salt-size pentru a permite diferite dimensiuni." << endl;
                            break;
                        }
                        
                        // Verify the generated key by re-encrypting the plaintext
                        vector<uint8_t> checkKey, checkIV;
                        if (DeriveKey_Synced_Fast(config.password, currentNonceOrSalt, 
                                                   finalResult.bestRounds, checkKey, checkIV)) {
                            // Încercăm re-criptarea plaintext-ului și comparăm cu ciphertext-ul generat
                            vector<uint8_t> reencrypted = EncryptAES_Fast(finalResult.bestPlaintext, checkKey, checkIV);
                            
                            if (!reencrypted.empty() && reencrypted.size() == finalResult.bestCiphertext.size() && 
                                reencrypted == finalResult.bestCiphertext) {
                                
                                cout << "[OK] Key verification successful!" << endl;
                                
                                // Create new record - PĂSTRĂM EXACT ACEAȘI STRUCTURĂ
                                vector<uint8_t> newRecord;
                                
                                // 1. Lungimea ciphertext-ului (trebuie să fie aceeași)
                                newRecord.push_back(static_cast<uint8_t>(oldEncryptedKey.size()));
                                
                                // 2. Ciphertext-ul nou (cu aceeași dimensiune)
                                newRecord.insert(newRecord.end(), finalResult.bestCiphertext.begin(), 
                                                 finalResult.bestCiphertext.end());
                                
                                // 3. Lungimea salt-ului (folosim dimensiunea curentă)
                                uint8_t currentSaltSize = static_cast<uint8_t>(currentNonceOrSalt.size());
                                newRecord.push_back(currentSaltSize);
                                
                                // 4. Salt-ul/nonce-ul (cu dimensiunea curentă)
                                newRecord.insert(newRecord.end(), currentNonceOrSalt.begin(), currentNonceOrSalt.end());
                                
                                // 5. Method (0 pentru AES-256-CBC)
                                uint32_t methodForced = 0;
                                uint8_t methodBytes[4];
                                memcpy(methodBytes, &methodForced, 4);
                                newRecord.insert(newRecord.end(), methodBytes, methodBytes + 4);
                                
                                // 6. Rounds
                                uint8_t roundBytes[4];
                                memcpy(roundBytes, &finalResult.bestRounds, 4);
                                newRecord.insert(newRecord.end(), roundBytes, roundBytes + 4);
                                
                                // 7. Extra data (dacă există) - păstrăm exact la fel
                                if (!extraData.empty()) {
                                    newRecord.insert(newRecord.end(), extraData.begin(), extraData.end());
                                }
                                
                                // VERIFICĂ DIMENSIUNEA FINALĂ - acum poate fi diferită dacă salt-ul are altă dimensiune
                                if (newRecord.size() != valVec.size()) {
                                    if (config.preserveOriginalSaltSize) {
                                        cerr << "[EROARE CRITICĂ] Dimensiunea noii înregistrări (" 
                                             << newRecord.size() << " bytes) diferă de cea originală (" 
                                             << valVec.size() << " bytes)!" << endl;
                                        cerr << "[EROARE] Wallet-ul NU va fi actualizat pentru a preveni coruperea." << endl;
                                        break;
                                    } else {
                                        cout << "[WARNING] Dimensiunea noii înregistrări (" 
                                             << newRecord.size() << " bytes) diferă de cea originală (" 
                                             << valVec.size() << " bytes)" << endl;
                                        cout << "[INFO] Continuăm deoarece --allow-different-salt-size este activat." << endl;
                                    }
                                }
                                
                                // Update database
                                Dbt newData(newRecord.data(), static_cast<u_int32_t>(newRecord.size()));
                                if (cursorp->put(&key, &newData, DB_CURRENT) == 0) {
                                    cout << "\n[SUCCESS] Wallet.dat updated successfully!" << endl;
                                    
                                    // Afișează ce a fost folosit
                                    if (usingNonce) {
                                        cout << "[INFO] Updated with extracted nonce: " 
                                             << ToHex(currentNonceOrSalt) << " (" 
                                             << currentNonceOrSalt.size() << " bytes)" << endl;
                                    } else {
                                        cout << "[INFO] Updated with original salt: " 
                                             << ToHex(currentNonceOrSalt) << " (" 
                                             << currentNonceOrSalt.size() << " bytes)" << endl;
                                    }
                                    
                                    if (newRecord.size() == valVec.size()) {
                                        cout << "[INFO] Structura păstrată perfect: " 
                                             << newRecord.size() << " bytes (la fel ca originalul)" << endl;
                                    } else {
                                        cout << "[INFO] Noua structură: " << newRecord.size() 
                                             << " bytes (original: " << valVec.size() << " bytes)" << endl;
                                    }
                                    
                                    success = true;
                                } else {
                                    cerr << "[ERROR] Failed to update wallet.dat" << endl;
                                }
                            } else {
                                cerr << "[ERROR] Key verification failed! Re-encryption did not match." << endl;
                                cerr << "Re-encrypted size: " << reencrypted.size() << ", expected: " << finalResult.bestCiphertext.size() << endl;
                                // Afișează primele 16 bytes pentru debugging
                                cerr << "Re-encrypted (first 16): " << ToHexPreview(reencrypted, 16) << endl;
                                cerr << "Original ciphertext (first 16): " << ToHexPreview(finalResult.bestCiphertext, 16) << endl;
                            }
                        }
                    }
                    
                    break;
                }
            }
        }
        
        if (!found) {
            cout << "\n[ERROR] MKey not found in wallet.dat" << endl;
        }
        
    } catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
    }
    
    // Cleanup
    if (cursorp) cursorp->close();
    if (pdb) {
        pdb->close(0);
        delete pdb;
    }
    env.close(0);
    
    SecureWipeString(config.password);
    EVP_cleanup();
    ERR_free_strings();
    
#ifdef USE_CUDA
    cudaDeviceReset();
#endif
    
    if (success) {
        cout << "\n============================================================" << endl;
        cout << "               OPERATION COMPLETED SUCCESSFULLY              " << endl;
        cout << "============================================================" << endl;
        cout << "Summary:" << endl;
        cout << "- Wallet updated with new encryption key" << endl;
        cout << "- Password: " << string(config.password.length(), '*') << endl;
        cout << "- Rounds: " << config.fixedRounds << endl;
        cout << "- Similarity achieved: " << finalResult.bestSimilarity * 100 << "%" << endl;
        if (config.enableBruteForce && finalResult.bestSimilarity >= config.targetSimilarity) {
            cout << "- Target similarity REACHED" << endl;
        }
        cout << "- " << (usingNonce ? "Nonce" : "Salt") << " used: " 
             << (usingNonce ? "EXTRACTED NONCE" : "ORIGINAL SALT") << endl;
        if (usingNonce) {
            cout << "- Nonce value: " << ToHexPreview(currentNonceOrSalt, 16) << endl;
            cout << "- Nonce size: " << currentNonceOrSalt.size() << " bytes" << endl;
        }
        cout << "- Device used: " << (config.useGPU ? "GPU" : "CPU") << endl;
        if (config.useGPU) {
            cout << "- GPU batch size: " << config.gpuBatchSize << endl;
        } else {
            cout << "- CPU threads: " << config.numThreads << endl;
        }
        if (config.useExtractedNonces && config.testAllNonces) {
            cout << "- Tested all " << extractedNonces.size() << " extracted nonces" << endl;
        }
        if (!config.preserveOriginalSaltSize) {
            cout << "- Different salt sizes allowed: YES" << endl;
        }
        cout << "============================================================" << endl;
    } else {
        cout << "\n[WARNING] Operation completed with warnings or was stopped" << endl;
        cout << "Best similarity achieved: " << finalResult.bestSimilarity * 100 << "%" << endl;
        if (config.useExtractedNonces) {
            cout << "Nonce/Salt used: " << (usingNonce ? "EXTRACTED NONCE" : "ORIGINAL SALT") << endl;
        }
        cout << "[INFO] Wallet.dat NU a fost modificat pentru a preveni coruperea." << endl;
    }
    
    return success ? 0 : 1;
}